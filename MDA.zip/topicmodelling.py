# -*- coding: utf-8 -*-
"""
Created on Sun May 15 15:26:37 2016

@author: alejandra
"""
import scipy.sparse

#import gensim
#from gensim import corpora, models
#corpus = corpora.BleiCorpus('./data/ap/ap.dat','./data/ap/vocab.txt')